import axios from "axios";
import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import "./App.css";


const Create = () => {
  const [values, setValues] = useState({
    firstname: '',
    lastname:'',
    maidanname:'',
    age:'',
    gender:'',
    gmail: '',
    amount:''
  })

  const navigate = useNavigate();
  const handleSubmit = () => {
    axios
      .post("http://localhost:2222/Data", values)
      .then((res) => {
        console.log(res)
        navigate("/");
      })
      .catch((err) => console.log(err));

  }

  return (
    <div align = "center">
      <div className="App">
      <button className="btn btn-primary">
            <Link to="/" style={{color:"white"}}>Logout</Link>
          </button>
        <div className="btn btn-success">Please provide your details as below</div>
        <fieldset>
        <form action="#" method="get" >
        <br/>
          <div>
          <label for="firstname">First Name: </label>
            <input onChange={e => setValues({...values, firstname: e.target.value})} type="text" required  placeholder="Enter Name" name="firstname" />
          </div>
        
          <div>
          <label for="lastname">Last Name:</label>
            <input onChange={e => setValues({...values,lastname:e.target.value})} type="text" required placeholder="Enter Name" name="lastname" />
          </div>
          
          <div>
          <label for="maidanname">Maidan Name: </label>
            <input onChange={e => setValues({...values, maidanname: e.target.value})} type="text" required placeholder="Enter Name" name="maidanname" />
          </div>
          
          <div>
          <label for="age">Age: </label>
            <input onChange={e => setValues({...values, age: e.target.value})} type="text" required placeholder="Enter Name" name="age"/>
          </div>
          
          <div>
          <label for="gender">Gender: </label>
            <input onChange={e => setValues({...values, gender: e.target.value})} type="text" required placeholder="Enter Name" name="gender" />
          </div>
          
          <div>
          <label for="email">Email: </label>
            <input onChange={e => setValues({...values, gmail:e.target.value})} type="email" required  placeholder="Enter Email" name="email" />
          </div>
          
          <div>
          <label for="amount">Amount: </label>
            <input onChange={e => setValues({...values, amount:e.target.value})} type="text" required  placeholder="Enter Amount" name= "amount" />
          </div>
        </form>
        </fieldset>
        <br/>
        <div>
          <button className="btn btn-primary" onClick={handleSubmit}>
            Submit
          </button> 
          &ensp;
          <button className="btn btn-primary">
            <Link to="/" style={{color:"white"}}>Cancel</Link>
          </button>
        </div>
      </div>
    </div>
  );
};

export default Create;
