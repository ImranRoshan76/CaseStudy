import { useState, useEffect } from "react";
import { Link, useParams, useNavigate} from "react-router-dom";
import axios from "axios";
import "./App.css";


const Update = () => {
  const [data, setData] = useState([]);
  const { id } = useParams();
  const [firstname, setFirstname] = useState("");
  const [lastname, setLastname] = useState("");
  const [maidanname, setMaidaname] = useState("");
  const [age, setAge] = useState("");
  const [gender, setGender] = useState("");
  const [gmail, setGmail] = useState("");
  const [amount, setAmount] = useState("");
  const homeMenu = useNavigate();

  useEffect(() => {
    axios
      .get(`http://localhost:2222/Data/${id}`)
      .then((res) => {
        setFirstname(res.data.firstname);
        setLastname(res.data.lastname);
        setMaidaname(res.data.maidanname);
        setAge(res.data.age);
        setGender(res.data.gender);
        setGmail(res.data.gmail);
        setAmount(res.data.amount);
      })
      .catch((err) => console.log(err));
  }, [id]);

  const handleSubmit = (e) => {
    e.preventDefault();
    axios
      .put(`http://localhost:2222/Data/${id}`, { firstname,lastname,maidanname,age,gender,gmail,amount })
      .then((res) => {
        console.log(res);
        homeMenu("/empdata");
      })
      .catch((err) => console.log(err));
  };

  return (
    <div>
        <div className="btn btn-success">Update User</div>
        <form>
          <div>
            <label for="firstname">First Name:</label>
            <input
              type="text"
              required
              placeholder="Enter Name"
              name="firstname"
              value={firstname}
              onChange={(e) => setFirstname(e.target.value)}
            />
          </div>
          <div>
            <label for="lastname">Last Name:</label>
            <input
              type="text"
              required
              placeholder="Enter Name"
              name="lastname"
              value={lastname}
              onChange={(e) => setLastname(e.target.value)}
            />
          </div>
          <div>
            <label for="maidanname">Maidan Name:</label>
            <input
              type="text"
              required
              placeholder="Enter Name"
              name="maidanname"
              value={maidanname}
              onChange={(e) => setMaidaname(e.target.value)}
            />
          </div>
          <div>
            <label for="age">Age:</label>
            <input
              type="text"
              required
              placeholder="Enter Age"
              name="age"
              value={age}
              onChange={(e) => setAge(e.target.value)}
            />
          </div>
          <div>
            <label for="gender">Gender:</label>
            <input
              type="text"
              required
              placeholder="Enter Gender"
              name="gender"
              value={gender}
              onChange={(e) => setGender(e.target.value)}
            />
          </div>
          <div>
            <label htmlFor="email">Your Email:</label>
            <input
              type="email"
              required
              placeholder="Enter Email"
              name="email"
              value={gmail}
              onChange={(e) => setGmail(e.target.value)}
            />
          </div>
          <div>
            <label for="amount">Amount:</label>
            <input
              type="text"
              required
              placeholder="Enter Amount"
              name="amount"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
            />
          </div>
        </form>
        <div>
          <button className="btn btn-primary" onClick={handleSubmit} type="submit">
            Update
          </button>&ensp;
          <Link to="/">
          <button className="btn btn-primary" type="reset">
            Cancel</button></Link>
          
        </div>
      </div>
  );
};

export default Update;
